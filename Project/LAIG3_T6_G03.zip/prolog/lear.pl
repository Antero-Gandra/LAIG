:- use_module(library(random)).
:- ensure_loaded('gameLogic.pl').
:- ensure_loaded('ia.pl').
